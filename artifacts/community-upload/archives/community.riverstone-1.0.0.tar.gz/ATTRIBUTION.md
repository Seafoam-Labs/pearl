Original shell palette example; Material colors generated with Matugen 4.2.0 from #2dd4a8. This independent package ID demonstrates catalog extensibility.
